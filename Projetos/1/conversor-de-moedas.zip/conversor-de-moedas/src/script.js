//GabrielCeconCarlsen

var dolar = parseFloat( prompt("Qual o valor em dólares ($) a ser convertido?"))

//1 dolar == 5,53 reais 
var real = (dolar * 5.53).toFixed(2)

alert("R$: "+real)



