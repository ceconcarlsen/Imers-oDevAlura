var celsius = parseInt(prompt("Qual a temperatura (ºC) a ser convertida? "))

var fahrenheit = (celsius)*(1.8) + 32

if(isNaN(fahrenheit)){ document.getElementById("resultado").innerHTML = "[ERRO]: Entrada inválida !!!"
}
else{
document.getElementById("resultado").innerHTML = "Resultado: " + fahrenheit + " ºF"
}