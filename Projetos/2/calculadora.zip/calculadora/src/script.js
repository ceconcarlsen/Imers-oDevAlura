var operacao = parseInt(prompt("1. SOMA (+)\n2. SUBTRAÇÃO (-)\n3. MULTIPLICAÇÃO (*)\n4. DIVISÃO (/)"));

var primeiroValor = parseInt(prompt("Digite o 1º valor: "))
var segundoValor = parseInt(prompt("Digite o 2º valor: "))

var resultado

if(operacao == 1){
  resultado = primeiroValor + segundoValor
  document.write("<h2>"+primeiroValor+" + "+segundoValor+ " =         "+resultado+"</h2>")
}
else if(operacao == 2){
  resultado = primeiroValor - segundoValor
  document.write("<h2>"+primeiroValor+" - "+segundoValor+ " =         "+resultado+"</h2>")
}
else if(operacao == 3){
  resultado = primeiroValor * segundoValor
  document.write("<h2>"+primeiroValor+" x "+segundoValor+ " =         "+resultado+"</h2>")
}
else if(operacao == 4){
  resultado = primeiroValor / segundoValor
  document.write("<h2>"+primeiroValor+" / "+segundoValor+ " =         "+resultado+"</h2>")
}
else{
  document.write("<h2>[ERRO]</h2>")
}

