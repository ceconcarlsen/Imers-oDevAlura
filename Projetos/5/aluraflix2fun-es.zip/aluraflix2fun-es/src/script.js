function adicionarFilmeFavorito(){
  
  var campoFilmeFavorito = document.querySelector("#filme")
  var filmeFavorito = campoFilmeFavorito.value
  console.log(filmeFavorito)
//ex: https://m.media-amazon.com/images/M/MV5BOTNiYmVjNjktZDhhNy00NGQ0LTg0YzYtYWVlMTVjMTQyMDU5XkEyXkFqcGdeQXVyMzY0MTE3NzU@._V1_UX182_CR0,0,182,268_AL_.jpg
  if(filmeFavorito.endsWith(".jpg")){
  adicionarFilmeFavoritoNaTela(filmeFavorito)
  }
  else{
    alert("[ERRO]: Link inválido !!!")
  } 
  campoFilmeFavorito.value = ""
}

function adicionarFilmeFavoritoNaTela(filme){
  
 var listaFilmes = document.querySelector("#listaFilmes") 
 var elementoFilme = "<img src=" + filme + ">"
 listaFilmes.innerHTML = listaFilmes.innerHTML + elementoFilme
  
}