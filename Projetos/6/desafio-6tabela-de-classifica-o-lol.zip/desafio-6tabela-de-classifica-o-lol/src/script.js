//Objetos iniciais
var paulo = {
  nome: "Paulo",
  vitorias: 0,
  empates: 0,
  derrotas: 0,
  pontos: 0
}
var rafa = {
  nome: "Rafaela",
  vitorias: 0,
  empates: 0,
  derrotas: 0,
  pontos: 0
}

//Função calcula pontos -> vitória: +15pdl, empate: 0pdl, derrota: -20pdl
function calculaPontos (jogador){
  var pontos = (jogador.vitorias * 15) - (jogador.derrotas * 20)
  return pontos
}
//Atribuindo pontuação a rafa e paulo
paulo.pontos = calculaPontos(paulo)
rafa.pontos = calculaPontos(rafa)

//Array de objetos
var jogadores = [paulo,rafa]

//Função para imprimir jogadores na tela
function exibirJogadoresNaTela(jogadores){
  var html = ""
  for(var i=0; i<jogadores.length; i++){
    html += "<tr><td>" + jogadores[i].nome + "</td>"
    html += "<td>" + jogadores[i].vitorias + "</td>"
    html += "<td>" + jogadores[i].empates + "</td>"
    html += "<td>" + jogadores[i].derrotas + "</td>"
    html += "<td>" + jogadores[i].pontos + "</td>"
    html += "<td><button onClick= 'adicionarVitoria("+ i + ")'>Vitória</button></td>"
    html += "<td><button onClick= 'adicionarEmpate("+ i + ")'>Empate</button></td>"
    html += "<td><button onClick= 'adicionarDerrota("+ i + ")'>Derrota</button></td></tr>"
  }
  var tabelaJogadores =   document.getElementById("tabelaJogadores")
  tabelaJogadores.innerHTML = html
}
//Exibindo o array de objetos na tabela do HTML 
exibirJogadoresNaTela(jogadores)

//Funções dos botoões
function adicionarVitoria(i){
  var jogador = jogadores[i]
  jogador.vitorias++
  jogador.pontos =  calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
  
  var celula = document.getElementById("celulaVitorias")
  celula.style.backgroundColor = "green"
  celula.style.color = "black"
  
  //window.setTimeout(função, tempo em ms, parametro da função)
  window.setTimeout(voltaCorPadrao, 200, celula)
 }

function adicionarEmpate(i){
  var jogador = jogadores[i]
  jogador.empates++
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
  
  var celula = document.getElementById("celulaEmpates")
  celula.style.backgroundColor = "yellow"
  celula.style.color = "black"
  
  //window.setTimeout(função, tempo em ms, parametro da função)
  window.setTimeout(voltaCorPadrao, 200, celula)
}
function adicionarDerrota(i){
  var jogador = jogadores[i]
  jogador.derrotas++
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
  
  var celula = document.getElementById("celulaDerrotas")
  celula.style.backgroundColor = "red"
  celula.style.color = "black"
  
  //window.setTimeout(função, tempo em ms, parametro da função)
  window.setTimeout(voltaCorPadrao, 200, celula)
}

function voltaCorPadrao(celula){
  celula.style.backgroundColor = "black"
  celula.style.color = "white"
}

function adicionaNovoJogador(){
  var nome = prompt("[NOVO JOGADOR]")
 
  if(nome != null){
   var novoJogador = {
    nome: nome,
    vitorias: 0,
    empates: 0,
    derrotas: 0,
    pontos: 0
  }
   
   jogadores.push(novoJogador)
   exibirJogadoresNaTela(jogadores)
  }
}



